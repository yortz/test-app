module Padrino
  VERSION = '0.0.1' #unless defined?(VERSION)
end