### AUTOMATICALLY GENERATED. DO NOT EDIT!
require 'padrino-core'
require 'padrino-helpers'
require 'padrino-mailer'
require 'padrino-routing'
